Bug Id:        14342982
                   
Bug Extract:   UDA FIELDS HAVE PERFORMANCE ISSUE.


Module:		                                             Revision 
POP_SIL_RetailItemUDADimensionLoad.xml                           1