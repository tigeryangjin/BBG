Bug Id:        14684808
                   
Bug Extract:   SDE & SIL HAS ISSUES ON ITEMDIFF, ITEMUDA, ITEMLST, PACK


Module:		                                             Revision 
POP_SIL_RetailItemListDimensionLoad.xml                         1
c14684808_0027_w_rtl_partition_map_g.sql			1

